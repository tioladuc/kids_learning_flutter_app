class AudioItem {
  final String id;
  final String title;
  final String audioUrl;

  AudioItem({
    required this.id,
    required this.title,
    required this.audioUrl,
  });

  factory AudioItem.fromJson(Map<String, dynamic> json) {
    return AudioItem(
      id: json['id'],
      title: json['title'],
      audioUrl: json['audio_url'],
    );
  }
}
