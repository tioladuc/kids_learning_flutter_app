import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/session_provider.dart';

class AppHeader extends StatelessWidget implements PreferredSizeWidget {
  const AppHeader({super.key});

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionProvider>();

    return AppBar(
      title: const Text('Kids Learning'),
      actions: [
        IconButton(
          icon: Icon(session.isLoggedIn ? Icons.logout : Icons.login),
          onPressed: () {
            if (session.isLoggedIn) {
              session.logout();
            }
          },
        )
      ],
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(56);
}
