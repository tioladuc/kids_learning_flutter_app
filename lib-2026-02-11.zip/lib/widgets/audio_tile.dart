import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/audio_item.dart';
import '../providers/audio_provider.dart';
import '../screens/audio_player_screen.dart';

class AudioTile extends StatelessWidget {
  final AudioItem audio;

  const AudioTile({super.key, required this.audio});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(audio.title),
      leading: const Icon(Icons.play_circle),
      trailing: IconButton(
        icon: const Icon(Icons.delete),
        onPressed: () async {
          final confirmed = await showDialog<bool>(
            context: context,
            builder: (_) => AlertDialog(
              title: const Text('Delete audio'),
              content: const Text('Are you sure?'),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete')),
              ],
            ),
          );

          if (confirmed == true) {
            context.read<AudioProvider>().deleteAudio(audio.id);
          }
        },
      ),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => AudioPlayerScreen(audio: audio),
          ),
        );
      },
    );
  }
}
