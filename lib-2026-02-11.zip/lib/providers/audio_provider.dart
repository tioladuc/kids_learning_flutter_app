import 'package:flutter/material.dart';
import '../models/audio_item.dart';
import '../core/api_client.dart';

class AudioProvider extends ChangeNotifier {
  List<AudioItem> audios = [];

  Future<void> loadAudios() async {
    final data = await ApiClient.get('/selfdictation');
    audios = (data as List)
        .map((e) => AudioItem.fromJson(e))
        .toList();
    notifyListeners();
  }

  Future<void> deleteAudio(String id) async {
    await ApiClient.delete('/selfdictation/$id');
    audios.removeWhere((a) => a.id == id);
    notifyListeners();
  }
}
