import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/session_provider.dart';
import '../widgets/app_header.dart';
import '../widgets/app_footer.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const AppHeader(),
      bottomNavigationBar: const AppFooter(),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () =>
                  context.read<SessionProvider>().login('child'),
              child: const Text('Login as Child'),
            ),
            ElevatedButton(
              onPressed: () =>
                  context.read<SessionProvider>().login('parent'),
              child: const Text('Login as Parent'),
            ),
          ],
        ),
      ),
    );
  }
}
