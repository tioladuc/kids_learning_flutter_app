import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import '../models/audio_item.dart';
import '../widgets/app_header.dart';

class AudioPlayerScreen extends StatefulWidget {
  final AudioItem audio;
  const AudioPlayerScreen({super.key, required this.audio});

  @override
  State<AudioPlayerScreen> createState() => _AudioPlayerScreenState();
}

class _AudioPlayerScreenState extends State<AudioPlayerScreen> {
  final player = AudioPlayer();

  @override
  void initState() {
    super.initState();
    player.setUrl(widget.audio.audioUrl);
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const AppHeader(),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(widget.audio.title),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                icon: const Icon(Icons.replay_10),
                onPressed: () => player.seek(
                  player.position - const Duration(seconds: 10),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.play_arrow),
                onPressed: player.play,
              ),
              IconButton(
                icon: const Icon(Icons.pause),
                onPressed: player.pause,
              ),
              IconButton(
                icon: const Icon(Icons.stop),
                onPressed: player.stop,
              ),
              IconButton(
                icon: const Icon(Icons.forward_10),
                onPressed: () => player.seek(
                  player.position + const Duration(seconds: 10),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
